(function(document, $) {
$(document).on('dialog-ready', function(e) {
	var selectedValue = $('#contentType select').val();
    var assetType = $('#assetType select').val();
    showHide();
});

$(document).on('selected.select','#contentType', function(e) {
    showHide();
});

$(document).on('selected.select','#assetType', function(e) {
    assetType();
});

    function showHide(){
        var selectedValue = $('#contentType select').val();

        if(selectedValue === ''){
            $("[name='./title2']").closest('.coral-Form-fieldwrapper').hide();            
            $("[name='./fontSize2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./desc2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./assetType2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./youtubeLink2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./desktopImage2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./mobileImage2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./altText2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./buttonText2']").closest('.coral-Form-fieldwrapper').hide();
			$("[name='./buttonLink2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./linkText2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./link2']").closest('.coral-Form-fieldwrapper').hide();
			$("[name='./autoPlay2']").closest('.coral-Form-fieldwrapper').hide();
		$("[name='./panel1BgColor2']").closest('.coral-Form-fieldwrapper').hide();
		$("[name='./panel2BgColor2']").closest('.coral-Form-fieldwrapper').hide();

        }else if(selectedValue === 'contentPanel1'){
            contentPanel1();

        }else if(selectedValue === 'contentPanel2'){
			contentPanel2();
        }
    }

    function contentPanel1(){

        $("[name='./title2']").closest('.coral-Form-fieldwrapper').show();            
        $("[name='./fontSize2']").closest('.coral-Form-fieldwrapper').show();
        $("[name='./desc2']").closest('.coral-Form-fieldwrapper').show();
        $("[name='./assetType2']").closest('.coral-Form-fieldwrapper').show();
        assetType();
        $("[name='./buttonText2']").closest('.coral-Form-fieldwrapper').show();
        $("[name='./buttonLink2']").closest('.coral-Form-fieldwrapper').show();
        $("[name='./linkText2']").closest('.coral-Form-fieldwrapper').show();
        $("[name='./link2']").parent('.coral-Form-fieldwrapper').show();
		$("[name='./panel1BgColor2']").closest('.coral-Form-fieldwrapper').show();
		$("[name='./panel2BgColor2']").closest('.coral-Form-fieldwrapper').hide();
    }

    function contentPanel2(){

        $("[name='./title2']").closest('.coral-Form-fieldwrapper').show();            
        $("[name='./fontSize2']").closest('.coral-Form-fieldwrapper').show();
        $("[name='./desc2']").closest('.coral-Form-fieldwrapper').show();
        $("[name='./assetType2']").closest('.coral-Form-fieldwrapper').show();
        assetType();
        $("[name='./buttonText2']").closest('.coral-Form-fieldwrapper').show();
        $("[name='./buttonLink2']").closest('.coral-Form-fieldwrapper').show();
        $("[name='./linkText2']").closest('.coral-Form-fieldwrapper').show();
        $("[name='./link2']").parent('.coral-Form-fieldwrapper').show();
		$("[name='./panel1BgColor2']").closest('.coral-Form-fieldwrapper').hide();
		$("[name='./panel2BgColor2']").closest('.coral-Form-fieldwrapper').show();
    }

    function assetType(){
		var assetType = $('#assetType select').val();
        var selectedValue = $('#contentType select').val();
        
        if(assetType === ''){
            $("[name='./youtubeLink2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./desktopImage2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./mobileImage2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./altText2']").closest('.coral-Form-fieldwrapper').hide();
			$("[name='./autoPlay2']").closest('.coral-Form-fieldwrapper').hide();
        }else if(assetType === 'image'){
            $("[name='./youtubeLink2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./desktopImage2']").closest('.coral-Form-fieldwrapper').show();
            $("[name='./mobileImage2']").closest('.coral-Form-fieldwrapper').show();
            $("[name='./altText2']").closest('.coral-Form-fieldwrapper').show();
			$("[name='./autoPlay2']").closest('.coral-Form-fieldwrapper').hide();
        }else if(assetType === 'video'){
            $("[name='./youtubeLink2']").closest('.coral-Form-fieldwrapper').show();
            $("[name='./desktopImage2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./mobileImage2']").closest('.coral-Form-fieldwrapper').hide();
            $("[name='./altText2']").closest('.coral-Form-fieldwrapper').hide();
			$("[name='./autoPlay2']").closest('.coral-Form-fieldwrapper').show();
        }
    }


})(document,Granite.$);