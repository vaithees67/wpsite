package com.eon.aem.uk.core.common.utility;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;

public class UtilityMethods extends WCMUsePojo {

	/** Default log. */
	private static final Logger LOGGER  = LoggerFactory.getLogger(UtilityMethods.class);
	
	@Override
	public void activate() throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * This method will Iterate the current page and its parent page to find out 
	 * the first locale page template and return the Page object
	 * In a site structure one locale template should be available  
	 * 
	 * @return page
	 */
	public static Page getResourcePage(Page currentPage,String strResourceType) {
		
		if(currentPage.getContentResource().getResourceType().equals(strResourceType)) {
			return currentPage;
		}

		do {
			currentPage = currentPage.getParent();
			if(currentPage.getContentResource().getResourceType().equals(strResourceType)) {
				return currentPage;
			}
			
		} while(!currentPage.getContentResource().getResourceType().equals(strResourceType) && currentPage.getParent() != null);
		
		return null;
	}



}
