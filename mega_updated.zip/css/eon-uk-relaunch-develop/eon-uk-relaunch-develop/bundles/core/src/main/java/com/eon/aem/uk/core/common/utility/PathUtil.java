package com.eon.aem.uk.core.common.utility;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;

/**
 * Utility to get the localepage path
 * 
 * @author somen.sarkar
 */
public class PathUtil extends WCMUsePojo {
	
	/** Default log. */
	private static final Logger LOGGER  = LoggerFactory.getLogger(PathUtil.class);
	private static String propertyName;
	private static final String LOCALE_PAGE_RESOURCE_TYPE = "eon-uk/components/structure/locale-page";
	
	@Override
	public void activate() throws Exception {
		LOGGER.debug("**Activating Utility Methods**");
		/**
		 * Getting the property name
		 */
		 propertyName = get("propertyName", String.class);

	}	
	
	/**
	 * Get the localepage Path e.g /content/eon-uk/en
	 * This method will iterate over the parent pages and once locale page is found, it will return the path
	 * 
	 * @return String
	 */
	
	public String getLocalePath(){

		LOGGER.debug("Class :", PathUtil.class.getName(), ": Method : getLocalePath() : [Enter]");

		String path = null;

		Page localPage  = UtilityMethods.getResourcePage(getCurrentPage(), LOCALE_PAGE_RESOURCE_TYPE);
		
		LOGGER.debug("Current Page is  : " , localPage.getPath());
		
		if(localPage != null){
			path = localPage.getPath();
		}
		
		LOGGER.debug("Path is  : ", path);
		LOGGER.debug("Class :", PathUtil.class.getName(), ": Method : getLocalePath() : [Exit]");
		
		return path;

	}
	
	/**
	 * Get the Value of the property from locale page template
	 * @return String
	 */
	
	public String getPropertyValue(){
		
		String propertyValue = null;
		String localePageProperties = getLocalePath() + "/" + JcrConstants.JCR_CONTENT;
		
		Resource resource= getResourceResolver().getResource(localePageProperties)!= null ? getResourceResolver().getResource(localePageProperties) : null;
		
		if(resource != null) {
			ValueMap pageProperties = resource.adaptTo(ValueMap.class);
			propertyValue = pageProperties != null ? pageProperties.get(propertyName, String.class) : null;	
		}	
			
		return propertyValue;
		
	}

}
