package com.eon.aem.uk.core.models;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

@Model(adaptables = SlingHttpServletRequest.class)
public class ReadTokenModel {
	private static final Logger log = LoggerFactory.getLogger(ReadTokenModel.class);

	@SlingObject
	ResourceResolver resourceResolver;

	@SlingObject
	Resource resource;

	@SlingObject
	ResourceResolver resolver;
	@Inject
	@Optional
	private String description;

	private String replacedText;



	public String getDescription() {

		return description;
	}

	public String getReplacedText() {
		return replacedText;
	}

	public void setReplacedText(String replacedText) {
		this.replacedText = replacedText;
	}

	@PostConstruct
	protected void init() {
		try {
			log.debug("init!!!! called!!!!!!!!!!!");

			Session session = resolver.adaptTo(Session.class);

			StringBuffer sb = new StringBuffer();
			Pattern pattern = Pattern.compile("\\$\\{(.*?)\\}");
			
			log.debug("description>>>" + description);

			if (description != null) {
				Matcher matcher = pattern.matcher(description);

				while (matcher.find()) {
					String occurrence = matcher.group(1);
					log.debug("occurrence>>>" + occurrence);
					PageManager pageManager = resolver.adaptTo(PageManager.class);
					Page currentPage = pageManager.getContainingPage(resource.getPath()).adaptTo(Page.class);

					Node currentPageNode;

					currentPageNode = session.getNode("/content/eon-uk/en/utilities/token-creation/jcr:content");

					String repString = currentPageNode.hasProperty(occurrence)
							? currentPageNode.getProperty(occurrence).getString()
							: "nomatch";
					log.debug("new repString>>>" + repString);

					if (repString != null)
						matcher.appendReplacement(sb, repString);

				}
				matcher.appendTail(sb);

				log.debug("new string>>>" + sb.toString());
				replacedText = sb.toString();
			}
		} catch (RepositoryException e) {
			log.debug("RepositoryException>>>" + e.getMessage());

		}
	}
}
