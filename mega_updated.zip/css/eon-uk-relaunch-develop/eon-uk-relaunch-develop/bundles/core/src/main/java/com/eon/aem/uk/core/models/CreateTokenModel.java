package com.eon.aem.uk.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

@Model(adaptables = Resource.class)
public class CreateTokenModel {
	private static final Logger log = LoggerFactory.getLogger(CreateTokenModel.class);

	@SlingObject
	ResourceResolver resourceResolver;

	@SlingObject
	Resource resource;

	@SlingObject
	ResourceResolver resolver;
	@Inject
	@Optional
	private String tokenKey;
	@Inject
	@Optional
	private String tokenValue;

	public String getTokenKey() {
		return tokenKey;
	}

	public void setTokenKey(String tokenKey) {
		this.tokenKey = tokenKey;
	}

	public String getTokenValue() {
		return tokenValue;
	}

	public void setTokenValue(String tokenValue) {
		this.tokenValue = tokenValue;
	}

	@PostConstruct
	protected void init() {
		try {
			
			log.debug("init!!!!!!!!!!!!!");

			Session session = resolver.adaptTo(Session.class);
			PageManager pageManager = resolver.adaptTo(PageManager.class);
			Page currentPage = pageManager.getContainingPage(resource.getPath()).adaptTo(Page.class);

			Node currentPageNode =session.getNode(currentPage.getPath() + "/jcr:content");

			if (tokenKey != null && tokenValue != null)
				if (currentPageNode.hasProperty(tokenKey))
					currentPageNode.getProperty(tokenKey).remove();
			session.save();
			currentPageNode.setProperty(tokenKey, tokenValue);
			log.debug("tokenKey>>>" +tokenKey);
			log.debug("tokenValue>>>" +tokenValue);

			session.save();

		} catch (Exception e) {
			log.debug("RepositoryException>>>" + e.getMessage());

		}
	}
}
