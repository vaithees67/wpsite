var dataLayer = window.dataLayer = window.dataLayer || [];

function cpImgClick(id,compName,compId){
       // console.log("id"+document.getElementById("cp-title-1-"+compId).innerHTML);

                dataLayer.push({
                                "event": "pnEvent_GA", 
                                "componentId": compId,
                                "componentName": compName,
                                "componentPosition": "MPU banner",
                                "interactionType": "click",
                                "ctaType": "image link",
                                "eventCategory": "content interaction",
                                "eventAction": "image link-click",
                                "eventLabel": "Responsive image",
                                "contentTitle": document.getElementById("cp-title-1-"+compId).innerHTML, 
                                "assetType": "image",
                                "assetName": "Responsive image"
                });
}

function cpBtnClick(id, item,compName,compId){
  //  console.log("id"+compName);
         //   console.log(document.getElementById("cp-title-1-"+compId).innerHTML);


                dataLayer.push({
                                "event": "pnEvent_GA", 
                                "componentId": compId,
                                "componentName": compName,
                                "componentPosition": "MPU banner",
                                "interactionType": "click",
                                "ctaType": "button",
                                "eventCategory": "content interaction",
                                "eventAction": "button-click",
                                "eventLabel": "Button Standard",
                                "contentTitle": document.getElementById("cp-title-1-"+compId).innerHTML, 
                                "assetType": item,
                                "assetName": "Test Image Name"
                });
}

function cpLinkClick(id,compName,compId){
        //console.log("id"+id);


       var cpCompId=id.split('cp-txtlnk-2-')[1];
            //console.log(document.getElementById("cp-title-1-"+cpCompId).innerHTML);

    dataLayer.push({
                                "event": "pnEvent_GA", 
                                "componentId": cpCompId,
                                "componentName": compName,
                                "componentPosition": "Component's Parent Organism",
                                "interactionType": "click",
                                "ctaType": "text link",
                                "eventCategory": "content interaction",
                                "eventAction": "text link-click",
                                "eventLabel": "Link",
                                "contentTitle": document.getElementById("cp-title-1-"+cpCompId).innerHTML, 
                                "assetType": "text link",
                                "assetName": "Test Link"
                });
}




function ftrImgClick(id,compName,compId){
       // console.log(document.getElementById("ftr-title-1-"+compId).innerHTML);

	dataLayer.push({
		"event": "pnEonEvent", 
		"componentId": compId,
		"componentName": compName,
		"componentPosition": "Component's Parent Organism",
		"iteractionType": "click",
		"ctaType": "image link",
		"eventCategory": "content interaction",
		"eventAction": "image link-click",
		"eventLabel": "Responsive image",
		"contentTitle": document.getElementById("ftr-title-1-"+compId).innerHTML, 
		"assetType": "image",
		"assetName": "Responsive image"
	});
}
function ftrLinkClick(id,compName,compId){
    //console.log("compId>>>"+compId);
    var featureCompId=id.split('ftr-txtlnk-1-')[1];
   // console.log(document.getElementById("ftr-title-1-"+featureCompId).innerHTML);
                dataLayer.push({
                                "event": "pnEvent_GA", 
                                "componentId": featureCompId,
                                "componentName": compName,
                                "componentPosition": "Component's Parent Organism",
                                "iteractionType": "click",
                                "ctaType": "text link",
                                "eventCategory": "feature interaction",
                                "eventAction": "text link-click",
                                "eventLabel": "Link",
                                "contentTitle": document.getElementById("ftr-title-1-"+featureCompId).innerHTML
                });
}
